<?php

    /**
     * Created by Master Vission.
     * Date: 9/22/2016
     */
    class Permissions_model extends CI_Model{

        var $permissions = array();

        function __construct(){
            parent::__construct();
        }

        function set_permissions($permission){
            $this->permissions = json_decode($permission);
            return $this->permissions;
        }

        function get($permission){
            if (isset($this->permissions->{$permission})) {
                return $this->permissions->{$permission};
            }
            return false;
        }

        function check($permission, $sub = "open"){
            if (isset($this->permissions->{$permission})) {
                if (isset($this->permissions->{$permission}->{$sub})) {
                    if ($this->permissions->{$permission}->{$sub} == 1) {
                        return true;
                    }
                } else {
                    die('no permissions');
                }
            }
        }

        function check2($permission, $sub = "open"){
            if (isset($this->permissions->{$permission})) {
                if (isset($this->permissions->{$permission}->{$sub})) {
                    if ($this->permissions->{$permission}->{$sub} == 1) {
                        return true;
                    }
                } else {
                    return false;
                }
            }
        }

    }
