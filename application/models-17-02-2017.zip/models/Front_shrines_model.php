<?php

    class Front_shrines_model extends CI_Model{

        private $table = 'maka_madina_shrines';

        public function __construct(){
            parent::__construct();
        }

        public function getShrinesInCity($city_id){
            $this->db->select('*');
            $this->db->from($this->table);
            $this->db->where('places_id', $city_id);
            $this->db->where('active', 1);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->result();
            } else {
                return false;
            }
        }

        public function getShrinesByTitle($shrine_title){
            $this->db->select('*');
            $this->db->from($this->table);
            $this->db->where('title_ar', $shrine_title);
            $this->db->where('active', 1);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                return $query->row();
            } else {
                return false;
            }
        }

    }
